# Unreleased

# 0.2.2 – 2020-08-31

- Reimplement the `Error` trait for `LocateManifestError`

# 0.2.1 – 2020-08-30 (yanked)

- Remove internal dependency on `thiserror` to reduce compile times
