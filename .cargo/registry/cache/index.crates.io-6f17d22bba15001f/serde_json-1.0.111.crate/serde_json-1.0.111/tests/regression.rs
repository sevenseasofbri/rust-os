mod regression {
    automod::dir!("tests/regression");
}
